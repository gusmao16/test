# ConectaStore — Sistema de Recomendação em Grafos em Rust

Disciplina: Data Structure Strategy and Implementation

---

## Links do Trabalho

- Repositório GitHub: [Link do Repositório do GitHub do Grupo]
- Vídeo Pitch (YouTube): [Link do Vídeo de Apresentação no YouTube]
- Relatório Técnico em PDF: relatorio-tecnico-conectastore.pdf

---

## Integrantes do Grupo

- Integrante 1 — RA/Matrícula
- Integrante 2 — RA/Matrícula
- Integrante 3 — RA/Matrícula

---

## Visão Geral do Projeto

O ConectaStore é uma solução de recomendação de produtos em tempo real desenvolvida em Rust para o e-commerce MegaStore. O sistema substitui algoritmos genéricos por uma arquitetura orientada a Grafos Heterogêneos Ponderados, conectando Clientes, Produtos e Categorias.

---

## Estrutura do Repositório

```text
conectastore/
├── Cargo.toml
├── README.md
├── src/
│   ├── lib.rs
│   ├── models.rs
│   ├── graph.rs
│   ├── recommender.rs
│   ├── benchmark.rs
│   └── main.rs
└── tests/
    └── integration_tests.rs
```

---

## Como Compilar e Executar

1. Compilar e executar:
   cargo run --release

2. Executar suíte de testes:
   cargo test
