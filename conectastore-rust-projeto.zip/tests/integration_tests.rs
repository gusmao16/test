use conectastore::{
    graph::Graph,
    models::{Category, Customer, Edge, EdgeType, Node, Product},
    recommender::Recommender,
};

#[test]
fn test_graph_creation_and_node_counting() {
    let mut graph = Graph::new();

    let p1 = Product { id: 1, title: "Notebook Pro".to_string(), category_id: 10, price: 4500.0 };
    let c1 = Customer { id: 100, name: "Maria".to_string(), email: "maria@test.com".to_string() };
    let cat1 = Category { id: 10, name: "Informática".to_string() };

    graph.add_product(p1);
    graph.add_customer(c1);
    graph.add_category(cat1);

    assert_eq!(graph.node_count(), 3);
}

#[test]
fn test_exclusion_of_already_purchased_products() {
    let mut graph = Graph::new();

    let p1 = Product { id: 1, title: "Mouse".to_string(), category_id: 1, price: 50.0 };
    let p2 = Product { id: 2, title: "Teclado".to_string(), category_id: 1, price: 150.0 };
    let c1 = Customer { id: 10, name: "João".to_string(), email: "joao@test.com".to_string() };

    graph.add_product(p1);
    graph.add_product(p2.clone());
    graph.add_customer(c1);

    // João comprou o Mouse (p1)
    graph.add_edge(
        Node::Customer(10),
        Edge::new(Node::Product(1), EdgeType::Bought { rating: Some(5) }, 1.0),
        true,
    );

    // Mouse é similar ao Teclado (p2)
    graph.add_edge(
        Node::Product(1),
        Edge::new(Node::Product(2), EdgeType::SimilarTo, 0.9),
        true,
    );

    let recommender = Recommender::new(&graph, 3, 0.85);
    let recs = recommender.recommend_for_customer(10, 5);

    // A recomendação DEVE conter apenas o Teclado (p2), NUNCA o Mouse (p1) já comprado
    assert_eq!(recs.len(), 1);
    assert_eq!(recs[0].0.id, 2);
}

#[test]
fn test_non_existent_customer_returns_empty() {
    let graph = Graph::new();
    let recommender = Recommender::new(&graph, 2, 0.85);
    let recs = recommender.recommend_for_customer(9999, 5);
    assert!(recs.is_empty());
}
