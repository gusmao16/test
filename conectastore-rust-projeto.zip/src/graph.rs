use std::collections::HashMap;
use crate::models::{Category, Customer, Edge, Node, Product};

/// Grafo Heterogêneo representado via Lista de Adjacência
#[derive(Debug, Default, Clone)]
pub struct Graph {
    /// Lista de Adjacência: Nó de Origem -> Lista de Arestas Saindo
    adjacency_list: HashMap<Node, Vec<Edge>>,
    /// Dicionários para acesso rápido O(1) aos metadados
    products: HashMap<u32, Product>,
    customers: HashMap<u32, Customer>,
    categories: HashMap<u32, Category>,
}

impl Graph {
    pub fn new() -> Self {
        Self::default()
    }

    /// Adiciona um Cliente ao Grafo
    pub fn add_customer(&mut self, customer: Customer) {
        let node = Node::Customer(customer.id);
        self.adjacency_list.entry(node).or_default();
        self.customers.insert(customer.id, customer);
    }

    /// Adiciona um Produto ao Grafo
    pub fn add_product(&mut self, product: Product) {
        let node = Node::Product(product.id);
        self.adjacency_list.entry(node).or_default();
        self.products.insert(product.id, product);
    }

    /// Adiciona uma Categoria ao Grafo
    pub fn add_category(&mut self, category: Category) {
        let node = Node::Category(category.id);
        self.adjacency_list.entry(node).or_default();
        self.categories.insert(category.id, category);
    }

    /// Adiciona uma Aresta Ponderada entre dois Nós (Direcionada ou Bidirecional)
    pub fn add_edge(&mut self, source: Node, edge: Edge, bidirectional: bool) {
        if bidirectional {
            let back_edge = Edge::new(source.clone(), edge.edge_type.clone(), edge.weight);
            self.adjacency_list
                .entry(edge.target.clone())
                .or_default()
                .push(back_edge);
        }
        self.adjacency_list.entry(source).or_default().push(edge);
    }

    /// Retorna os vizinhos (arestas conectadas) de um determinado nó
    pub fn get_neighbors(&self, node: &Node) -> Option<&Vec<Edge>> {
        self.adjacency_list.get(node)
    }

    /// Obtém os dados de um Produto por ID
    pub fn get_product(&self, product_id: u32) -> Option<&Product> {
        self.products.get(&product_id)
    }

    /// Obtém os dados de um Cliente por ID
    pub fn get_customer(&self, customer_id: u32) -> Option<&Customer> {
        self.customers.get(&customer_id)
    }

    /// Retorna a quantidade total de vértices
    pub fn node_count(&self) -> usize {
        self.adjacency_list.len()
    }

    /// Retorna a quantidade total de arestas
    pub fn edge_count(&self) -> usize {
        self.adjacency_list.values().map(|v| v.len()).sum()
    }

    /// Retorna o grau de um determinado nó
    pub fn degree(&self, node: &Node) -> usize {
        self.adjacency_list.get(node).map_or(0, |edges| edges.len())
    }

    /// Retorna todos os produtos comprados diretamente por um cliente
    pub fn get_customer_purchases(&self, customer_id: u32) -> Vec<u32> {
        let customer_node = Node::Customer(customer_id);
        let mut purchases = Vec::new();

        if let Some(edges) = self.get_neighbors(&customer_node) {
            for edge in edges {
                if let Node::Product(p_id) = edge.target {
                    purchases.push(p_id);
                }
            }
        }
        purchases
    }
}
