use conectastore::{
    benchmark::run_synthetic_benchmark,
    graph::Graph,
    models::{Category, Customer, Edge, EdgeType, Node, Product},
    recommender::Recommender,
};

fn main() {
    println!("==========================================================================");
    println!("     CONECTASTORE — SISTEMA DE RECOMENDAÇÃO EM GRAFOS EM RUST            ");
    println!("==========================================================================");

    // 1. Inicialização do Grafo
    let mut graph = Graph::new();

    println!("\n[1] POPULANDO O GRAFO COM DADOS REAIS DA MEGASTORE...");

    // Adicionando Categorias
    let cat_eletr = Category { id: 101, name: "Eletrônicos".to_string() };
    let cat_games = Category { id: 102, name: "Games e Consoles".to_string() };
    let cat_livros = Category { id: 103, name: "Livros Técnicos".to_string() };

    graph.add_category(cat_eletr.clone());
    graph.add_category(cat_games.clone());
    graph.add_category(cat_livros.clone());

    // Adicionando Produtos
    let p1 = Product { id: 1, title: "Smartphone Galaxy S24 Ultra".to_string(), category_id: 101, price: 5999.0 };
    let p2 = Product { id: 2, title: "Headset Gamer Sem Fio 7.1".to_string(), category_id: 102, price: 450.0 };
    let p3 = Product { id: 3, title: "Console PlayStation 5 Slim".to_string(), category_id: 102, price: 3799.0 };
    let p4 = Product { id: 4, title: "Monitor Gamer 144Hz 1ms IPS".to_string(), category_id: 101, price: 1299.0 };
    let p5 = Product { id: 5, title: "Livro: Programming Rust (2nd Ed)".to_string(), category_id: 103, price: 280.0 };
    let p6 = Product { id: 6, title: "Cadeira Ergonômica Pro Gamer".to_string(), category_id: 102, price: 890.0 };

    graph.add_product(p1.clone());
    graph.add_product(p2.clone());
    graph.add_product(p3.clone());
    graph.add_product(p4.clone());
    graph.add_product(p5.clone());
    graph.add_product(p6.clone());

    // Conectando Produtos às Categorias
    graph.add_edge(Node::Product(1), Edge::new(Node::Category(101), EdgeType::BelongsTo, 0.5), true);
    graph.add_edge(Node::Product(2), Edge::new(Node::Category(102), EdgeType::BelongsTo, 0.5), true);
    graph.add_edge(Node::Product(3), Edge::new(Node::Category(102), EdgeType::BelongsTo, 0.5), true);
    graph.add_edge(Node::Product(4), Edge::new(Node::Category(101), EdgeType::BelongsTo, 0.5), true);
    graph.add_edge(Node::Product(5), Edge::new(Node::Category(103), EdgeType::BelongsTo, 0.5), true);
    graph.add_edge(Node::Product(6), Edge::new(Node::Category(102), EdgeType::BelongsTo, 0.5), true);

    // Conectando Produtos Similares/Co-comprados diretamente
    graph.add_edge(Node::Product(3), Edge::new(Node::Product(2), EdgeType::SimilarTo, 0.9), true);
    graph.add_edge(Node::Product(3), Edge::new(Node::Product(6), EdgeType::SimilarTo, 0.8), true);
    graph.add_edge(Node::Product(1), Edge::new(Node::Product(4), EdgeType::SimilarTo, 0.85), true);

    // Adicionando Clientes
    let c1 = Customer { id: 1001, name: "Ana Silva".to_string(), email: "ana.silva@email.com".to_string() };
    let c2 = Customer { id: 1002, name: "Carlos Eduardo".to_string(), email: "carlos.eduardo@email.com".to_string() };

    graph.add_customer(c1.clone());
    graph.add_customer(c2.clone());

    // Histórico de Compras (Arestas de Cliente -> Produto)
    // Ana comprou o PlayStation 5 (p3) e o Livro de Rust (p5)
    graph.add_edge(Node::Customer(1001), Edge::new(Node::Product(3), EdgeType::Bought { rating: Some(5) }, 1.0), true);
    graph.add_edge(Node::Customer(1001), Edge::new(Node::Product(5), EdgeType::Bought { rating: Some(5) }, 1.0), true);

    // Carlos comprou o PS5 (p3) e o Headset Gamer (p2)
    graph.add_edge(Node::Customer(1002), Edge::new(Node::Product(3), EdgeType::Bought { rating: Some(5) }, 1.0), true);
    graph.add_edge(Node::Customer(1002), Edge::new(Node::Product(2), EdgeType::Bought { rating: Some(4) }, 0.8), true);

    println!("   -> Vértices totais no Grafo: {}", graph.node_count());
    println!("   -> Arestas totais no Grafo:  {}", graph.edge_count());

    // 2. Executando Recomendação Personalizada
    println!("\n[2] GERANDO RECOMENDAÇÕES PERSONALIZADAS PARA: {} (ID: {})", c1.name, c1.id);
    println!("    Histórico de Compras da Ana: PS5 (ID 3), Livro Rust (ID 5)");

    let recommender = Recommender::new(&graph, 3, 0.85);
    let top_recommendations = recommender.recommend_for_customer(c1.id, 3);

    println!("\n--- RECOMENDAÇÕES GERADAS VIA GRAFO (BFS k-hops) ---");
    for (rank, (product, score)) in top_recommendations.iter().enumerate() {
        println!(
            "   {}. [Score: {:.4}] ID: {} - {} (R$ {:.2})",
            rank + 1,
            score,
            product.id,
            product.title,
            product.price
        );
    }

    // 3. Execução dos Benchmarks de Desempenho e Escalabilidade
    println!("\n[3] EXECUTANDO BENCHMARKS DE ESCALABILIDADE EM RUST...");
    
    let bench_small = run_synthetic_benchmark(500, 2000, 2);
    let bench_medium = run_synthetic_benchmark(2000, 10000, 2);
    let bench_large = run_synthetic_benchmark(5000, 25000, 2);

    println!("\n+-----------------------------------------------------------------------------------+");
    println!("| CENÁRIO DE TESTE               | VÉRTICES | ARESTAS  | TEMPO BUILD | RECOMENDAÇÃO |");
    println!("+-----------------------------------------------------------------------------------+");
    println!(
        "| {:<30} | {:<8} | {:<8} | {:<9.2} ms | {:<10.2} µs |",
        bench_small.scenario, bench_small.node_count, bench_small.edge_count, bench_small.build_time_ms, bench_small.recommendation_time_us
    );
    println!(
        "| {:<30} | {:<8} | {:<8} | {:<9.2} ms | {:<10.2} µs |",
        bench_medium.scenario, bench_medium.node_count, bench_medium.edge_count, bench_medium.build_time_ms, bench_medium.recommendation_time_us
    );
    println!(
        "| {:<30} | {:<8} | {:<8} | {:<9.2} ms | {:<10.2} µs |",
        bench_large.scenario, bench_large.node_count, bench_large.edge_count, bench_large.build_time_ms, bench_large.recommendation_time_us
    );
    println!("+-----------------------------------------------------------------------------------+");
    println!("\n-> Conclusão: O tempo de recomendação se mantém em ordem de SUB-MILISSEGUNDOS (< 1ms)!");
    println!("==========================================================================");
}
