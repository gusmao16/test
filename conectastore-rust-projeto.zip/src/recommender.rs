use std::collections::{HashMap, HashSet, VecDeque};
use crate::graph::Graph;
use crate::models::{Node, Product};

/// Motor de Recomendação Baseado em Busca em Largura (BFS) com Ponderação e Decaimento
pub struct Recommender<'a> {
    graph: &'a Graph,
    max_hops: usize,
    decay_factor: f64,
}

impl<'a> Recommender<'a> {
    pub fn new(graph: &'a Graph, max_hops: usize, decay_factor: f64) -> Self {
        Self {
            graph,
            max_hops,
            decay_factor,
        }
    }

    /// Gera recomendações personalizadas de produtos para um determinado cliente
    pub fn recommend_for_customer(
        &self,
        customer_id: u32,
        top_n: usize,
    ) -> Vec<(Product, f64)> {
        let start_node = Node::Customer(customer_id);

        // Se o cliente não existir no grafo, retorna vetor vazio
        if self.graph.get_customer(customer_id).is_none() {
            return Vec::new();
        }

        // Identifica produtos já comprados pelo cliente para exclusão
        let purchased_products: HashSet<u32> = self
            .graph
            .get_customer_purchases(customer_id)
            .into_iter()
            .collect();

        // Estruturas auxiliares para o percurso BFS
        // Fila armazena: (Nó Atual, Profundidade/Hops, Peso Acumulado do Caminho)
        let mut queue: VecDeque<(Node, usize, f64)> = VecDeque::new();
        let mut visited: HashSet<Node> = HashSet::new();
        let mut product_scores: HashMap<u32, f64> = HashMap::new();

        // Inicializa BFS a partir do nó do cliente
        queue.push_back((start_node.clone(), 0, 1.0));
        visited.insert(start_node);

        while let Some((current_node, current_hop, current_weight)) = queue.pop_front() {
            if current_hop >= self.max_hops {
                continue;
            }

            if let Some(edges) = self.graph.get_neighbors(&current_node) {
                for edge in edges {
                    let next_node = &edge.target;
                    let next_hop = current_hop + 1;
                    
                    // Cálculo da atenuação por distância (decaimento geométrico)
                    let step_weight = edge.weight * self.decay_factor.powi((next_hop - 1) as i32);
                    let accumulated_weight = current_weight * step_weight;

                    // Se for um Produto e o salto for >= 2 (recomendação indireta)
                    if let Node::Product(p_id) = next_node {
                        if !purchased_products.contains(p_id) {
                            *product_scores.entry(*p_id).or_insert(0.0) += accumulated_weight;
                        }
                    }

                    // Adiciona à fila se ainda não visitado e dentro do limite de hops
                    if !visited.contains(next_node) && next_hop < self.max_hops {
                        visited.insert(next_node.clone());
                        queue.push_back((next_node.clone(), next_hop, accumulated_weight));
                    }
                }
            }
        }

        // Mapeia IDs para structs Product e ordena decrescentemente por Score
        let mut recommendations: Vec<(Product, f64)> = product_scores
            .into_iter()
            .filter_map(|(p_id, score)| {
                self.graph.get_product(p_id).map(|p| (p.clone(), score))
            })
            .collect();

        recommendations.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        recommendations.truncate(top_n);

        recommendations
    }
}
