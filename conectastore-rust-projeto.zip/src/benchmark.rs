use std::time::Instant;
use crate::graph::Graph;
use crate::models::{Category, Customer, Edge, EdgeType, Node, Product};
use crate::recommender::Recommender;

pub struct BenchmarkResult {
    pub scenario: String,
    pub node_count: usize,
    pub edge_count: usize,
    pub build_time_ms: f64,
    pub recommendation_time_us: f64,
    pub top_recommendations_count: usize,
}

pub fn run_synthetic_benchmark(num_customers: u32, num_products: u32, max_hops: usize) -> BenchmarkResult {
    let start_build = Instant::now();
    let mut graph = Graph::new();

    // 1. Inserir Categorias
    for cat_id in 1..=10 {
        graph.add_category(Category {
            id: cat_id,
            name: format!("Categoria {}", cat_id),
        });
    }

    // 2. Inserir Produtos
    for p_id in 1..=num_products {
        let cat_id = (p_id % 10) + 1;
        graph.add_product(Product {
            id: p_id,
            title: format!("Produto MegaStore #{}", p_id),
            category_id: cat_id,
            price: 50.0 + (p_id as f64 * 0.5),
        });

        // Conectar Produto à Categoria
        graph.add_edge(
            Node::Product(p_id),
            Edge::new(Node::Category(cat_id), EdgeType::BelongsTo, 0.5),
            true,
        );
    }

    // 3. Inserir Clientes e Histórico de Compras
    for c_id in 1..=num_customers {
        graph.add_customer(Customer {
            id: c_id,
            name: format!("Cliente {}", c_id),
            email: format!("cliente{}@megastore.com", c_id),
        });

        // Cada cliente compra entre 3 e 8 produtos
        let purchases = (c_id % 5) + 3;
        for i in 0..purchases {
            let target_prod = ((c_id + i * 7) % num_products) + 1;
            graph.add_edge(
                Node::Customer(c_id),
                Edge::new(
                    Node::Product(target_prod),
                    EdgeType::Bought { rating: Some(5) },
                    1.0,
                ),
                true,
            );
        }
    }

    let build_duration = start_build.elapsed();

    // 4. Executar Medição de Recomendação
    let recommender = Recommender::new(&graph, max_hops, 0.85);
    let start_rec = Instant::now();
    let recommendations = recommender.recommend_for_customer(1, 5);
    let rec_duration = start_rec.elapsed();

    BenchmarkResult {
        scenario: format!("Sintético (V={}, E={})", graph.node_count(), graph.edge_count()),
        node_count: graph.node_count(),
        edge_count: graph.edge_count(),
        build_time_ms: build_duration.as_secs_f64() * 1000.0,
        recommendation_time_us: rec_duration.as_secs_f64() * 1_000_000.0,
        top_recommendations_count: recommendations.len(),
    }
}
