use serde::{Deserialize, Serialize};

/// Identificador de Nó no Grafo
#[derive(Debug, Clone, Hash, PartialEq, Eq, Serialize, Deserialize)]
pub enum Node {
    Customer(u32),
    Product(u32),
    Category(u32),
}

/// Dados cadastrais do Cliente
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Customer {
    pub id: u32,
    pub name: String,
    pub email: String,
}

/// Dados do Produto no e-commerce MegaStore
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Product {
    pub id: u32,
    pub title: String,
    pub category_id: u32,
    pub price: f64,
}

/// Categoria de Produtos
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Category {
    pub id: u32,
    pub name: String,
}

/// Tipos de Aresta com pesos padrão e atributos específicos
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum EdgeType {
    Bought { rating: Option<u8> },
    BelongsTo,
    SimilarTo,
    Rated { stars: u8 },
}

/// Estrutura de Aresta Ponderada e Direcionada/Não-Direcionada
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Edge {
    pub target: Node,
    pub edge_type: EdgeType,
    pub weight: f64,
}

impl Edge {
    pub fn new(target: Node, edge_type: EdgeType, weight: f64) -> Self {
        Self {
            target,
            edge_type,
            weight,
        }
    }
}
